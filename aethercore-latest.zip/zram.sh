    #!/system/bin/sh
echo 1 > /sys/block/zram0/reset
echo 1073741824 > /sys/block/zram0/disksize  # 1024MB
mkswap /dev/block/zram0
swapon /dev/block/zram0
