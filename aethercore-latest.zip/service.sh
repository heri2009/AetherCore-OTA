#!/system/bin/sh
# AetherCore - Service Script (Runs at boot)

# Boost I/O performance again after boot
echo "deadline" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null
echo 512 > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null


echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/

#!/system/bin/sh
# AetherCore - Service script (boot-time)
echo "AetherCore service running..." >> /data/local/tmp/aethercore.log

nohup sh /data/adb/modules_update/aethercore/aetherctl.sh &


