#!/system/bin/sh
chmod +x /data/adb/modules/aethercore/aetherctl
ln -sf /data/adb/modules/aethercore/aetherctl /system/bin/aetherctl
