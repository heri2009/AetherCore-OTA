#!/system/bin/sh
# GPU + Charging + Rendering Tweaks
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo 850000000 > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo 850000000 > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq

setprop debug.egl.hw 1
setprop debug.hwui.renderer skiagl
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.cpurend.vsync false
setprop debug.egl.swapinterval 0
setprop debug.composition.type gpu
setprop debug.sf.enable_hwc_vds 1
setprop touch.boost 1
setprop ro.config.gpu_boost 1
setprop debug.sf.hw 1
setprop debug.sf.early_phase_offset_ns 1000000
setprop debug.sf.early_app_phase_offset_ns 1000000
setprop debug.sf.phase_offset_ns 2000000
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.renderengine.backend skiaglthreaded
setprop persist.sys.sf.color_saturation 1.2
setprop persist.sys.sf.native_mode 1
echo N > /sys/module/dvfs_core/parameters/enabled 2>/dev/null
echo 0 > /sys/module/msm_thermal/core_control/enabled 2>/dev/null
echo 0 > /sys/module/msm_thermal/vdd_restriction/enabled 2>/dev/null

# Charging
echo 1 > /sys/class/power_supply/battery/input_suspend 2>/dev/null
echo 1 > /sys/class/qcom-battery/step_charging_enabled 2>/dev/null
echo 1 > /sys/class/qcom-battery/recharge_enabled 2>/dev/null
echo 0 > /sys/class/qcom-battery/charging_restrict_enabled 2>/dev/null
echo 100 > /sys/class/power_supply/battery/charge_stop_level 2>/dev/null
echo 4200000 > /sys/class/power_supply/battery/voltage_max 2>/dev/null
echo 4000000 > /sys/class/power_supply/battery/constant_charge_voltage 2>/dev/null
echo 1800000 > /sys/class/qcom-battery/constant_charge_current_max 2>/dev/null

am broadcast -a android.intent.action.SHOW_TOAST --es msg "The application has been optimized 🚀"
