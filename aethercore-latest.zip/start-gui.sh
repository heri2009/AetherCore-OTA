#!/data/data/com.termux/files/usr/bin/bash
echo "[AetherCore GUI] Starting web server..."
cd /data/adb/modules/aethercore/ui || exit 1
python3 -m http.server 8080
