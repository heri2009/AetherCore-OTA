#!/system/bin/sh
if [ "$1" = "off" ]; then
  echo 0 > /sys/module/msm_thermal/core_control/enabled 2>/dev/null
  echo N > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
  echo "[AetherCore] Thermal disabled."
elif [ "$1" = "on" ]; then
  echo 1 > /sys/module/msm_thermal/core_control/enabled 2>/dev/null
  echo Y > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
  echo "[AetherCore] Thermal enabled."
else
  echo "Usage: aetherctl thermal [on|off]"
fi
