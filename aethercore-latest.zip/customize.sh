#!/system/bin/sh
cp -rf $MODPATH/system/* /system/
chmod -R 755 $MODPATH/system/aethercore
sh $MODPATH/system/aethercore/gpu_boost.sh
