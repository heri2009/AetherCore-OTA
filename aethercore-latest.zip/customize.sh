#!/system/bin/sh
echo "[AetherCore] Applying full boost tweaks..."
echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
for cpu in /sys/devices/system/cpu/cpu[1-9]*/cpufreq/scaling_governor; do
  echo performance > "$cpu" 2>/dev/null
done
echo 96 > /proc/sys/vm/swappiness
echo 10 > /proc/sys/vm/dirty_background_ratio
echo 50 > /proc/sys/vm/dirty_ratio
echo 0 > /proc/sys/vm/oom_kill_allocating_task
echo 0 > /proc/sys/kernel/randomize_va_space
echo 4096 > /proc/sys/vm/min_free_kbytes
for i in /sys/block/*/queue/scheduler; do echo cfq > $i 2>/dev/null; done
for i in /sys/block/*/queue/nr_requests; do echo 128 > $i 2>/dev/null; done
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse
echo 1 > /proc/sys/net/ipv4/tcp_syncookies
echo 1 > /proc/sys/net/ipv4/tcp_timestamps
echo 1 > /proc/sys/net/ipv4/tcp_sack
echo 1 > /proc/sys/net/ipv4/tcp_window_scaling
echo 0 > /proc/sys/fs/dir-notify-enable
echo 1 > /proc/sys/fs/file-max
echo 50 > /proc/sys/vm/vfs_cache_pressure
[ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo performance > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo 1 > /sys/module/wakelock/parameters/enable_event_log 2>/dev/null
echo 0 > /sys/class/android_usb/android0/enable 2>/dev/null
echo 1 > /sys/module/cpu_boost/parameters/input_boost_enabled 2>/dev/null
echo "4096 87380 6291456" > /proc/sys/net/ipv4/tcp_rmem
echo "4096 16384 4194304" > /proc/sys/net/ipv4/tcp_wmem
echo 0 > /sys/module/logger/parameters/debug_enable 2>/dev/null
echo 0 > /sys/module/printk/parameters/console_suspend 2>/dev/null
echo 500 > /proc/sys/vm/dirty_expire_centisecs
echo 1000 > /proc/sys/vm/dirty_writeback_centisecs
echo "[AetherCore] ⚡ Boost applied successfully."
