#!/system/bin/sh
ui_print " "
ui_print "╔══════════════════════════════════════╗"
ui_print "║  ⚡ Installing AetherCore (-) v1.8   ║"
ui_print "║         Unique Code: AC153-202508020934       ║"
ui_print "╚══════════════════════════════════════╝"
sleep 1

progress() {
  ui_print -n "["
  for i in $(seq 1 $1); do
    ui_print -n "█"
    sleep 0.1
  done
  for i in $(seq $1 20); do
    ui_print -n " "
  done
  ui_print "]"
}

ui_print ">>> Loading modules..."
progress 4
ui_print ">>> Selecting Boost Mode..."
progress 6
ui_print "    Volume UP = Aggressive 🔥"
ui_print "    Volume DOWN = Balanced 🌙"

CHOICE=$(getevent -qlc 1 | grep -E 'KEY_VOLUME(UP|DOWN)' | awk '{ print $3 }')

if [ "$CHOICE" = "KEY_VOLUMEUP" ]; then
    ui_print ">>> Aggressive Boost selected 🔥"
    setprop aethercore.boost aggressive
elif [ "$CHOICE" = "KEY_VOLUMEDOWN" ]; then
    ui_print ">>> Balanced Boost selected 🌙"
    setprop aethercore.boost balanced
else
    ui_print ">>> No input, default: Balanced 🌙"
    setprop aethercore.boost balanced
fi

progress 10
ui_print ">>> Applying GPU & Charging Tweaks..."
progress 16
ui_print ">>> Finalizing Installation..."
progress 20

ui_print "✅ AetherCore v1.8 Installed!"
ui_print " "
